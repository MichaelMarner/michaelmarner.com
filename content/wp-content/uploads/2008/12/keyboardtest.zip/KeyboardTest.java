//first thing we need to do is import java.util, so that we can use Scanner
import java.util.Scanner;

//We need to import the IO library so we can use BufferedReader
import java.io.*;

/**
 * KeyboardTest from Michael's Java VTM Episode 4, using Scanner.
 * 
 * As of Java 5, it is unnecessary to write your own class for extracting
 * data from the keyboard. The Java API now provides you with a class called
 * Scanner, which has many methods for extracting data from input streams.
 *
 * This file is a modified version of KeyboardTest, from Episode 4 of the 
 * Java VTM. The code has been modified to use Scanner to get the data, 
 * Instead of the Keyboard class that I had written earlier.
 *
 * @author Michael Marner
 */
public class KeyboardTest {

    /**
     * Main Method, creates some test variables, gets some data from
     * The keyboard, and prints out the results.
     *
     * @param args The command line arguments, this array is not used in this program.
     *
     */
    public static void main(String[] args) {
        
        /**
         * Using BufferedReader may throw an IOException, so we need to catch it.
         */
        try {
            
            //Create the test variables
            int testInt;
            double testDouble;
            char testChar;
            String testString;
            
            //Create the scanner object
            Scanner scanner = new Scanner(System.in);
            
            //Scanner isn't really suited for getting whole lines from the input stream. Buffered Reader is much better at it
            //So lets create a BufferedReader as well.
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            
            //Get the data from the keyboard
            System.out.println("Please enter an int");
            testInt = scanner.nextInt();
            
            System.out.println("Please enter a double");
            testDouble = scanner.nextDouble();
            
            
            System.out.println("Please enter a char");
            
            //readline returns a String, so we get the character
            testChar = reader.readLine().charAt(0);
            
            System.out.println("Please enter a String");
            testString = reader.readLine();
            
            //Print out the results
            System.out.println("The int you entered was " + testInt);
            System.out.println("The double you entered was " + testDouble);
            System.out.println("The char you entered was " + testChar);
            System.out.println("The String you entered was " + testString);
        }
        
        catch (IOException e) {
            System.out.println("Error getting data from keyboard");
        }

    }

}